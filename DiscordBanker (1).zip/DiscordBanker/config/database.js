const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        // Use local MongoDB instance on Replit
        const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/discord-economy';
        
        await mongoose.connect(mongoURI, {
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
        });

        console.log('✅ MongoDB connecté avec succès');
    } catch (error) {
        console.error('❌ Erreur de connexion MongoDB:', error);
        
        // Don't exit process, continue without database for now
        console.log('⚠️ Continuant sans base de données...');
    }
};

module.exports = connectDB;
