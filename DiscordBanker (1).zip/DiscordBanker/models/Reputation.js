const mongoose = require('mongoose');

const reputationSchema = new mongoose.Schema({
    user_id: {
        type: String,
        required: true,
        unique: true
    },
    score: {
        type: Number,
        default: 100
    },
    level: {
        type: Number,
        default: 1
    },
    experience: {
        type: Number,
        default: 0
    },
    achievements: [{
        name: String,
        description: String,
        earned_at: {
            type: Date,
            default: Date.now
        },
        icon: String
    }],
    trading_stats: {
        successful_sales: {
            type: Number,
            default: 0
        },
        successful_purchases: {
            type: Number,
            default: 0
        },
        total_volume: {
            type: Number,
            default: 0
        },
        cancelled_orders: {
            type: Number,
            default: 0
        },
        disputes: {
            type: Number,
            default: 0
        }
    },
    badges: [{
        type: String,
        enum: [
            'trustworthy_trader',
            'big_spender',
            'entrepreneur',
            'bank_manager',
            'market_maker',
            'rookie_trader',
            'veteran_trader',
            'whale',
            'penny_pincher',
            'speed_trader'
        ]
    }],
    last_activity: {
        type: Date,
        default: Date.now
    },
    last_daily_reward: {
        type: Date,
        default: null
    },
    daily_streak: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
});

// Calculate level based on experience
reputationSchema.methods.calculateLevel = function() {
    return Math.floor(this.experience / 1000) + 1;
};

// Get reputation tier
reputationSchema.methods.getReputationTier = function() {
    if (this.score >= 900) return { name: 'Legendary', color: '#FFD700', emoji: '🏆' };
    if (this.score >= 800) return { name: 'Excellent', color: '#9932CC', emoji: '💎' };
    if (this.score >= 700) return { name: 'Very Good', color: '#4169E1', emoji: '⭐' };
    if (this.score >= 600) return { name: 'Good', color: '#32CD32', emoji: '✅' };
    if (this.score >= 500) return { name: 'Average', color: '#FFA500', emoji: '📊' };
    if (this.score >= 400) return { name: 'Below Average', color: '#FF6347', emoji: '⚠️' };
    return { name: 'Poor', color: '#DC143C', emoji: '❌' };
};

module.exports = mongoose.model('Reputation', reputationSchema);