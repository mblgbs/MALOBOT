const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    buyer_id: {
        type: String,
        required: true
    },
    seller_id: {
        type: String,
        required: true
    },
    item: {
        type: String,
        required: true
    },
    quantity: {
        type: Number,
        required: true
    },
    price_total: {
        type: Number,
        required: true
    },
    status: {
        type: String,
        enum: ['pending', 'accepted', 'rejected', 'delivered'],
        default: 'pending'
    },
    message_id: {
        type: String,
        default: null
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Order', orderSchema);
