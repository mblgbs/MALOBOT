const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    user_id: {
        type: String,
        required: true,
        unique: true
    },
    wallet: {
        type: Number,
        default: 1000
    },
    bank: {
        solde: {
            type: Number,
            default: 0
        },
        actifs: {
            type: [String],
            default: []
        },
        dettes: {
            type: [String],
            default: []
        },
        historique: {
            type: [String],
            default: []
        }
    },
    role: {
        type: String,
        default: 'client',
        enum: ['client', 'vendeur']
    },
    shop_channel_id: {
        type: String,
        default: null
    },
    stock: {
        type: Map,
        of: {
            price: Number,
            quantity: Number
        },
        default: new Map()
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('User', userSchema);
