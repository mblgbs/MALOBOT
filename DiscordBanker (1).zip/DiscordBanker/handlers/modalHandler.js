const User = require('../models/User');
const { createSuccessEmbed, createErrorEmbed } = require('../utils/embeds');

module.exports = {
    async execute(interaction) {
        const customId = interaction.customId;

        try {
            if (customId === 'add_item_modal') {
                await this.handleAddItemModal(interaction);
            }
        } catch (error) {
            console.error('Erreur dans modalHandler:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors du traitement de votre demande.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    },

    async handleAddItemModal(interaction) {
        const itemName = interaction.fields.getTextInputValue('item_name').toLowerCase().trim();
        const priceText = interaction.fields.getTextInputValue('item_price').trim();
        const quantityText = interaction.fields.getTextInputValue('item_quantity').trim();

        // Validation des données
        const price = parseFloat(priceText);
        const quantity = parseInt(quantityText);

        if (isNaN(price) || price <= 0) {
            const errorEmbed = createErrorEmbed(
                'Prix invalide',
                'Le prix doit être un nombre positif.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (isNaN(quantity) || quantity <= 0) {
            const errorEmbed = createErrorEmbed(
                'Quantité invalide',
                'La quantité doit être un nombre entier positif.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        // Vérifier que l'utilisateur est vendeur
        const user = await User.findOne({ user_id: interaction.user.id });
        if (!user || user.role !== 'vendeur') {
            const errorEmbed = createErrorEmbed(
                'Accès refusé',
                'Vous devez être vendeur pour ajouter des articles.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        // Ajouter ou mettre à jour l'article
        const existingItem = user.stock.get(itemName);
        if (existingItem) {
            // Mise à jour de l'article existant
            existingItem.price = price;
            existingItem.quantity += quantity;
            user.stock.set(itemName, existingItem);
        } else {
            // Nouvel article
            user.stock.set(itemName, { price, quantity });
        }

        await user.save();

        const actionText = existingItem ? 'mis à jour' : 'ajouté';
        const newQuantity = existingItem ? existingItem.quantity : quantity;

        const successEmbed = createSuccessEmbed(
            `✅ Article ${actionText}`,
            `**${itemName}** a été ${actionText} avec succès !\n\n` +
            `💰 Prix: **${price} 💵** par unité\n` +
            `📦 Stock total: **${newQuantity}** unités\n` +
            `💵 Valeur totale: **${price * newQuantity} 💵**\n\n` +
            `Les clients peuvent maintenant acheter cet article avec \`/acheter\`.`
        );

        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    }
};
