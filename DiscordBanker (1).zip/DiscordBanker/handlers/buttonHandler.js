const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ButtonBuilder, ButtonStyle } = require('discord.js');
const User = require('../models/User');
const Order = require('../models/Order');
const ReputationManager = require('../utils/reputationManager');
const { createSuccessEmbed, createErrorEmbed, createInfoEmbed } = require('../utils/embeds');

module.exports = {
    async execute(interaction) {
        const customId = interaction.customId;
        const userId = interaction.user.id;

        try {
            if (customId === 'add_item') {
                await this.handleAddItem(interaction);
            } else if (customId === 'edit_item') {
                await this.handleEditItem(interaction);
            } else if (customId === 'delete_item') {
                await this.handleDeleteItem(interaction);
            } else if (customId === 'view_orders') {
                await this.handleViewOrders(interaction);
            } else if (customId === 'view_stock') {
                await this.handleViewStock(interaction);
            } else if (customId.startsWith('accept_order_')) {
                await this.handleAcceptOrder(interaction);
            } else if (customId.startsWith('reject_order_')) {
                await this.handleRejectOrder(interaction);
            } else if (customId.startsWith('deliver_order_')) {
                await this.handleDeliverOrder(interaction);
            }
        } catch (error) {
            console.error('Erreur dans buttonHandler:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors du traitement de votre demande.'
            );
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },

    async handleAddItem(interaction) {
        const modal = new ModalBuilder()
            .setCustomId('add_item_modal')
            .setTitle('Ajouter un Article');

        const nameInput = new TextInputBuilder()
            .setCustomId('item_name')
            .setLabel('Nom de l\'article')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(50);

        const priceInput = new TextInputBuilder()
            .setCustomId('item_price')
            .setLabel('Prix unitaire (💵)')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(10);

        const quantityInput = new TextInputBuilder()
            .setCustomId('item_quantity')
            .setLabel('Quantité en stock')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(10);

        const nameRow = new ActionRowBuilder().addComponents(nameInput);
        const priceRow = new ActionRowBuilder().addComponents(priceInput);
        const quantityRow = new ActionRowBuilder().addComponents(quantityInput);

        modal.addComponents(nameRow, priceRow, quantityRow);

        await interaction.showModal(modal);
    },

    async handleViewStock(interaction) {
        const user = await User.findOne({ user_id: interaction.user.id });
        
        if (!user || user.role !== 'vendeur') {
            const errorEmbed = createErrorEmbed(
                'Accès refusé',
                'Vous devez être vendeur pour accéder à cette fonction.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (!user.stock || user.stock.size === 0) {
            const infoEmbed = createInfoEmbed(
                '📊 Votre Stock',
                'Aucun article en stock.\n\nUtilisez le bouton **Ajouter Article** pour commencer.'
            );
            return interaction.reply({ embeds: [infoEmbed], ephemeral: true });
        }

        let stockList = '';
        let totalValue = 0;
        
        for (const [item, data] of user.stock) {
            const itemValue = data.price * data.quantity;
            totalValue += itemValue;
            stockList += `**${item}**\n`;
            stockList += `├ Prix: ${data.price} 💵/u\n`;
            stockList += `├ Stock: ${data.quantity} unités\n`;
            stockList += `└ Valeur: ${itemValue} 💵\n\n`;
        }

        const stockEmbed = createInfoEmbed(
            '📊 Votre Stock Actuel',
            stockList + `**💰 Valeur totale du stock: ${totalValue} 💵**`
        );

        await interaction.reply({ embeds: [stockEmbed], ephemeral: true });
    },

    async handleViewOrders(interaction) {
        const orders = await Order.find({ 
            seller_id: interaction.user.id,
            status: { $in: ['pending', 'accepted'] }
        }).sort({ createdAt: -1 });

        if (orders.length === 0) {
            const infoEmbed = createInfoEmbed(
                '📦 Vos Commandes',
                'Aucune commande en attente.'
            );
            return interaction.reply({ embeds: [infoEmbed], ephemeral: true });
        }

        let ordersList = '';
        for (const order of orders) {
            const statusEmoji = order.status === 'pending' ? '⏳' : '✅';
            ordersList += `${statusEmoji} **${order.item}** x${order.quantity}\n`;
            ordersList += `├ Acheteur: <@${order.buyer_id}>\n`;
            ordersList += `├ Prix: ${order.price_total} 💵\n`;
            ordersList += `└ Statut: ${order.status}\n\n`;
        }

        const ordersEmbed = createInfoEmbed(
            '📦 Vos Commandes Actives',
            ordersList
        );

        await interaction.reply({ embeds: [ordersEmbed], ephemeral: true });
    },

    async handleAcceptOrder(interaction) {
        const orderId = interaction.customId.replace('accept_order_', '');
        const order = await Order.findById(orderId);

        if (!order || order.seller_id !== interaction.user.id) {
            const errorEmbed = createErrorEmbed(
                'Commande introuvable',
                'Cette commande n\'existe pas ou ne vous appartient pas.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (order.status !== 'pending') {
            const errorEmbed = createErrorEmbed(
                'Commande déjà traitée',
                'Cette commande a déjà été traitée.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        // Vérifier le stock
        const seller = await User.findOne({ user_id: order.seller_id });
        const stockData = seller.stock.get(order.item);

        if (!stockData || stockData.quantity < order.quantity) {
            const errorEmbed = createErrorEmbed(
                'Stock insuffisant',
                'Vous n\'avez plus assez de stock pour cette commande.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        // Accepter la commande
        order.status = 'accepted';
        await order.save();

        // Retirer du stock
        stockData.quantity -= order.quantity;
        seller.stock.set(order.item, stockData);
        await seller.save();

        // Mettre à jour la réputation du vendeur
        await ReputationManager.addExperience(order.seller_id, 25, 'Commande acceptée');
        await ReputationManager.updateReputationScore(order.seller_id, 3, 'Réactivité commerciale');

        // Mettre à jour le message avec le bouton livrer
        const deliverButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`deliver_order_${order._id}`)
                    .setLabel('Marquer comme livré')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('📦')
            );

        const acceptedEmbed = createSuccessEmbed(
            '✅ Commande Acceptée',
            `**Article :** ${order.item}\n` +
            `**Quantité :** ${order.quantity}\n` +
            `**Acheteur :** <@${order.buyer_id}>\n` +
            `**Prix :** ${order.price_total} 💵\n\n` +
            `Stock mis à jour automatiquement.\n` +
            `Cliquez sur **Marquer comme livré** une fois la livraison effectuée.`
        );

        await interaction.update({
            embeds: [acceptedEmbed],
            components: [deliverButton]
        });

        // Notifier l'acheteur
        const buyer = await User.findOne({ user_id: order.buyer_id });
        if (buyer) {
            const guild = interaction.guild;
            const buyerUser = await guild.members.fetch(order.buyer_id);
            
            try {
                const notifEmbed = createSuccessEmbed(
                    '✅ Commande Acceptée',
                    `Votre commande a été acceptée par le vendeur !\n\n` +
                    `**Article :** ${order.item}\n` +
                    `**Quantité :** ${order.quantity}\n` +
                    `**Prix :** ${order.price_total} 💵\n\n` +
                    `La livraison va être effectuée sous peu.`
                );
                
                await buyerUser.send({ embeds: [notifEmbed] });
            } catch (error) {
                console.log('Impossible d\'envoyer un DM à l\'acheteur');
            }
        }
    },

    async handleRejectOrder(interaction) {
        const orderId = interaction.customId.replace('reject_order_', '');
        const order = await Order.findById(orderId);

        if (!order || order.seller_id !== interaction.user.id) {
            const errorEmbed = createErrorEmbed(
                'Commande introuvable',
                'Cette commande n\'existe pas ou ne vous appartient pas.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (order.status !== 'pending') {
            const errorEmbed = createErrorEmbed(
                'Commande déjà traitée',
                'Cette commande a déjà été traitée.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        // Rejeter la commande
        order.status = 'rejected';
        await order.save();

        // Rembourser l'acheteur
        const buyer = await User.findOne({ user_id: order.buyer_id });
        if (buyer) {
            buyer.wallet += order.price_total;
            await buyer.save();
        }

        // Pénalité de réputation pour le vendeur qui refuse
        await ReputationManager.updateReputationScore(order.seller_id, -5, 'Commande refusée');
        await ReputationManager.recordTransaction(order.buyer_id, 'cancelled', order.price_total);

        const rejectedEmbed = createErrorEmbed(
            '❌ Commande Refusée',
            `**Article :** ${order.item}\n` +
            `**Quantité :** ${order.quantity}\n` +
            `**Acheteur :** <@${order.buyer_id}>\n` +
            `**Prix :** ${order.price_total} 💵\n\n` +
            `L'acheteur a été remboursé automatiquement.`
        );

        await interaction.update({
            embeds: [rejectedEmbed],
            components: []
        });

        // Notifier l'acheteur
        if (buyer) {
            const guild = interaction.guild;
            const buyerUser = await guild.members.fetch(order.buyer_id);
            
            try {
                const notifEmbed = createErrorEmbed(
                    '❌ Commande Refusée',
                    `Votre commande a été refusée par le vendeur.\n\n` +
                    `**Article :** ${order.item}\n` +
                    `**Quantité :** ${order.quantity}\n` +
                    `**Prix :** ${order.price_total} 💵\n\n` +
                    `Vous avez été remboursé automatiquement.`
                );
                
                await buyerUser.send({ embeds: [notifEmbed] });
            } catch (error) {
                console.log('Impossible d\'envoyer un DM à l\'acheteur');
            }
        }
    },

    async handleDeliverOrder(interaction) {
        const orderId = interaction.customId.replace('deliver_order_', '');
        const order = await Order.findById(orderId);

        if (!order || order.seller_id !== interaction.user.id) {
            const errorEmbed = createErrorEmbed(
                'Commande introuvable',
                'Cette commande n\'existe pas ou ne vous appartient pas.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (order.status !== 'accepted') {
            const errorEmbed = createErrorEmbed(
                'Commande non acceptée',
                'Cette commande n\'a pas encore été acceptée.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        // Marquer comme livré
        order.status = 'delivered';
        await order.save();

        // Payer le vendeur (retirer 5% de commission)
        const seller = await User.findOne({ user_id: order.seller_id });
        const commission = Math.floor(order.price_total * 0.05);
        const sellerPayment = order.price_total - commission;

        seller.wallet += sellerPayment;
        seller.bank.historique.push(`Vente: ${order.item} x${order.quantity} - Reçu ${sellerPayment} 💵 (commission: ${commission} 💵) - ${new Date().toLocaleString('fr-FR')}`);
        await seller.save();

        // Mettre à jour la réputation pour la transaction complétée
        await ReputationManager.recordTransaction(order.seller_id, 'sale', order.price_total);
        await ReputationManager.recordTransaction(order.buyer_id, 'purchase', order.price_total);

        // Vérifier les nouveaux achievements
        const sellerAchievements = await ReputationManager.checkAchievements(order.seller_id);
        const buyerAchievements = await ReputationManager.checkAchievements(order.buyer_id);

        const deliveredEmbed = createSuccessEmbed(
            '📦 Commande Livrée',
            `**Article :** ${order.item}\n` +
            `**Quantité :** ${order.quantity}\n` +
            `**Acheteur :** <@${order.buyer_id}>\n` +
            `**Prix :** ${order.price_total} 💵\n\n` +
            `💰 Vous avez reçu: **${sellerPayment} 💵**\n` +
            `🏦 Commission prélevée: **${commission} 💵** (5%)\n\n` +
            `Transaction terminée avec succès !`
        );

        await interaction.update({
            embeds: [deliveredEmbed],
            components: []
        });

        // Notifier les achievements aux utilisateurs
        const guild = interaction.guild;
        
        // Notifications vendeur
        if (sellerAchievements.length > 0) {
            try {
                const sellerUser = await guild.members.fetch(order.seller_id);
                for (const achievement of sellerAchievements) {
                    const achievementEmbed = createSuccessEmbed(
                        `🎉 Nouvel Achievement Débloqué !`,
                        `${achievement.icon} **${achievement.description}**\n\n` +
                        `+${achievement.experience} XP bonus !`
                    );
                    await sellerUser.send({ embeds: [achievementEmbed] });
                }
            } catch (error) {
                console.log('Impossible d\'envoyer un DM au vendeur pour les achievements');
            }
        }

        // Notifier l'acheteur
        const buyer = await User.findOne({ user_id: order.buyer_id });
        if (buyer) {
            const buyerUser = await guild.members.fetch(order.buyer_id);
            
            try {
                const notifEmbed = createSuccessEmbed(
                    '📦 Commande Livrée',
                    `Votre commande a été livrée avec succès !\n\n` +
                    `**Article :** ${order.item}\n` +
                    `**Quantité :** ${order.quantity}\n` +
                    `**Prix :** ${order.price_total} 💵\n\n` +
                    `Merci pour votre achat !`
                );
                
                await buyerUser.send({ embeds: [notifEmbed] });

                // Notifier les achievements acheteur
                if (buyerAchievements.length > 0) {
                    for (const achievement of buyerAchievements) {
                        const achievementEmbed = createSuccessEmbed(
                            `🎉 Nouvel Achievement Débloqué !`,
                            `${achievement.icon} **${achievement.description}**\n\n` +
                            `+${achievement.experience} XP bonus !`
                        );
                        await buyerUser.send({ embeds: [achievementEmbed] });
                    }
                }
            } catch (error) {
                console.log('Impossible d\'envoyer un DM à l\'acheteur');
            }
        }
    }
};
