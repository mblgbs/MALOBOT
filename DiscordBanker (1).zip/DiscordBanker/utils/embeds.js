const { EmbedBuilder } = require('discord.js');

module.exports = {
    createSuccessEmbed(title, description) {
        return new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor(0x2ecc71) // Vert
            .setTimestamp();
    },

    createErrorEmbed(title, description) {
        return new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor(0xe74c3c) // Rouge
            .setTimestamp();
    },

    createInfoEmbed(title, description) {
        return new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor(0x3498db) // Bleu
            .setTimestamp();
    },

    createWarningEmbed(title, description) {
        return new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor(0xf39c12) // Orange
            .setTimestamp();
    }
};
