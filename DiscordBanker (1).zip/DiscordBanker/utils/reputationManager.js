const Reputation = require('../models/Reputation');
const { createSuccessEmbed } = require('./embeds');

class ReputationManager {
    static async initializeReputation(userId) {
        try {
            let reputation = await Reputation.findOne({ user_id: userId });
            if (!reputation) {
                reputation = new Reputation({ user_id: userId });
                await reputation.save();
            }
            return reputation;
        } catch (error) {
            console.error('Erreur lors de l\'initialisation de la réputation:', error);
            return null;
        }
    }

    static async addExperience(userId, amount, reason) {
        try {
            let reputation = await this.initializeReputation(userId);
            if (!reputation) return null;

            const oldLevel = reputation.calculateLevel();
            reputation.experience += amount;
            const newLevel = reputation.calculateLevel();

            if (newLevel > oldLevel) {
                reputation.level = newLevel;
                // Bonus de niveau
                reputation.score += (newLevel - oldLevel) * 10;
                await reputation.save();
                return { levelUp: true, newLevel, reason };
            }

            await reputation.save();
            return { levelUp: false, experience: amount, reason };
        } catch (error) {
            console.error('Erreur lors de l\'ajout d\'expérience:', error);
            return null;
        }
    }

    static async updateReputationScore(userId, change, reason) {
        try {
            let reputation = await this.initializeReputation(userId);
            if (!reputation) return null;

            reputation.score = Math.max(0, Math.min(1000, reputation.score + change));
            reputation.last_activity = new Date();
            await reputation.save();

            return { newScore: reputation.score, change, reason };
        } catch (error) {
            console.error('Erreur lors de la mise à jour de la réputation:', error);
            return null;
        }
    }

    static async recordTransaction(userId, type, amount) {
        try {
            let reputation = await this.initializeReputation(userId);
            if (!reputation) return null;

            // Mettre à jour les statistiques
            if (type === 'sale') {
                reputation.trading_stats.successful_sales += 1;
                reputation.trading_stats.total_volume += amount;
                await this.addExperience(userId, 50, 'Vente réussie');
                await this.updateReputationScore(userId, 5, 'Transaction réussie');
            } else if (type === 'purchase') {
                reputation.trading_stats.successful_purchases += 1;
                reputation.trading_stats.total_volume += amount;
                await this.addExperience(userId, 25, 'Achat réalisé');
                await this.updateReputationScore(userId, 2, 'Participation au marché');
            } else if (type === 'cancelled') {
                reputation.trading_stats.cancelled_orders += 1;
                await this.updateReputationScore(userId, -3, 'Commande annulée');
            }

            await reputation.save();
            await this.checkAchievements(userId);
            return reputation;
        } catch (error) {
            console.error('Erreur lors de l\'enregistrement de la transaction:', error);
            return null;
        }
    }

    static async checkAchievements(userId) {
        try {
            const reputation = await Reputation.findOne({ user_id: userId });
            if (!reputation) return [];

            const newAchievements = [];
            const existingAchievements = reputation.achievements.map(a => a.name);

            // Définir les achievements
            const achievements = [
                {
                    name: 'first_sale',
                    condition: reputation.trading_stats.successful_sales >= 1,
                    description: 'Effectuer votre première vente',
                    icon: '🎉',
                    experience: 100
                },
                {
                    name: 'merchant',
                    condition: reputation.trading_stats.successful_sales >= 10,
                    description: 'Effectuer 10 ventes avec succès',
                    icon: '🏪',
                    experience: 200
                },
                {
                    name: 'big_trader',
                    condition: reputation.trading_stats.total_volume >= 10000,
                    description: 'Atteindre 10,000 💵 de volume de transactions',
                    icon: '💰',
                    experience: 300
                },
                {
                    name: 'trusted_seller',
                    condition: reputation.score >= 800,
                    description: 'Atteindre un score de réputation de 800+',
                    icon: '⭐',
                    experience: 500
                },
                {
                    name: 'active_trader',
                    condition: reputation.trading_stats.successful_purchases >= 20,
                    description: 'Effectuer 20 achats avec succès',
                    icon: '🛒',
                    experience: 250
                },
                {
                    name: 'market_veteran',
                    condition: reputation.level >= 10,
                    description: 'Atteindre le niveau 10',
                    icon: '🏆',
                    experience: 1000
                }
            ];

            // Vérifier chaque achievement
            for (const achievement of achievements) {
                if (achievement.condition && !existingAchievements.includes(achievement.name)) {
                    reputation.achievements.push({
                        name: achievement.name,
                        description: achievement.description,
                        icon: achievement.icon
                    });
                    
                    // Ajouter l'expérience bonus
                    reputation.experience += achievement.experience;
                    newAchievements.push(achievement);
                }
            }

            // Vérifier les badges
            await this.updateBadges(reputation);
            
            await reputation.save();
            return newAchievements;
        } catch (error) {
            console.error('Erreur lors de la vérification des achievements:', error);
            return [];
        }
    }

    static async updateBadges(reputation) {
        const badges = [];

        // Badge basé sur le score de réputation
        if (reputation.score >= 900) badges.push('trustworthy_trader');
        if (reputation.trading_stats.total_volume >= 50000) badges.push('whale');
        if (reputation.trading_stats.successful_sales >= 50) badges.push('entrepreneur');
        if (reputation.level >= 5) badges.push('veteran_trader');
        if (reputation.level <= 2) badges.push('rookie_trader');
        if (reputation.trading_stats.total_volume >= 100000) badges.push('big_spender');

        reputation.badges = badges;
    }

    static async getLeaderboard(limit = 10) {
        try {
            return await Reputation.find({})
                .sort({ score: -1, level: -1, experience: -1 })
                .limit(limit);
        } catch (error) {
            console.error('Erreur lors de la récupération du classement:', error);
            return [];
        }
    }

    static async getUserRank(userId) {
        try {
            const userReputation = await Reputation.findOne({ user_id: userId });
            if (!userReputation) return null;

            const rank = await Reputation.countDocuments({
                $or: [
                    { score: { $gt: userReputation.score } },
                    { 
                        score: userReputation.score, 
                        level: { $gt: userReputation.level } 
                    },
                    { 
                        score: userReputation.score, 
                        level: userReputation.level,
                        experience: { $gt: userReputation.experience }
                    }
                ]
            });

            return rank + 1;
        } catch (error) {
            console.error('Erreur lors du calcul du rang:', error);
            return null;
        }
    }
}

module.exports = ReputationManager;