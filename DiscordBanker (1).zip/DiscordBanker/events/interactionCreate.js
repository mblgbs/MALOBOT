const { Events } = require('discord.js');
const buttonHandler = require('../handlers/buttonHandler');
const modalHandler = require('../handlers/modalHandler');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (interaction.isChatInputCommand()) {
            const command = interaction.client.commands.get(interaction.commandName);

            if (!command) {
                console.error(`❌ Commande ${interaction.commandName} non trouvée.`);
                return;
            }

            try {
                await command.execute(interaction);
            } catch (error) {
                console.error('❌ Erreur lors de l\'exécution de la commande:', error);
                const errorMessage = { 
                    content: 'Une erreur est survenue lors de l\'exécution de cette commande !', 
                    ephemeral: true 
                };
                
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp(errorMessage);
                } else {
                    await interaction.reply(errorMessage);
                }
            }
        } else if (interaction.isButton()) {
            await buttonHandler.execute(interaction);
        } else if (interaction.isModalSubmit()) {
            await modalHandler.execute(interaction);
        }
    },
};
