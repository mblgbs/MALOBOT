const { Events, REST, Routes } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`✅ Bot connecté en tant que ${client.user.tag}!`);

        // Déployer les commandes slash
        const commands = [];
        client.commands.forEach(command => {
            commands.push(command.data.toJSON());
        });

        const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN || 'your-discord-bot-token');

        try {
            console.log('🔄 Déploiement des commandes slash...');

            const clientId = process.env.CLIENT_ID || client.user.id;
            const guildId = process.env.GUILD_ID;

            if (guildId) {
                // Déploiement pour un serveur spécifique (plus rapide pour le développement)
                await rest.put(
                    Routes.applicationGuildCommands(clientId, guildId),
                    { body: commands }
                );
                console.log('✅ Commandes slash déployées (serveur spécifique)');
            } else {
                // Déploiement global (peut prendre jusqu'à 1 heure)
                await rest.put(
                    Routes.applicationCommands(clientId),
                    { body: commands }
                );
                console.log('✅ Commandes slash déployées (global)');
            }
        } catch (error) {
            console.error('❌ Erreur lors du déploiement des commandes:', error);
        }

        // Définir le statut du bot
        client.user.setActivity('Gérer l\'économie virtuelle', { type: 3 });
    },
};
