const { SlashCommandBuilder } = require('discord.js');
const Reputation = require('../../models/Reputation');
const ReputationManager = require('../../utils/reputationManager');
const { createInfoEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reputation')
        .setDescription('Affiche votre profil de réputation économique')
        .addUserOption(option =>
            option.setName('utilisateur')
                .setDescription('Voir la réputation d\'un autre utilisateur')
                .setRequired(false)
        ),
    
    async execute(interaction) {
        const targetUser = interaction.options.getUser('utilisateur') || interaction.user;
        const userId = targetUser.id;

        try {
            let reputation = await Reputation.findOne({ user_id: userId });
            
            if (!reputation) {
                reputation = await ReputationManager.initializeReputation(userId);
                if (!reputation) {
                    const errorEmbed = createErrorEmbed(
                        'Erreur système',
                        'Impossible d\'initialiser la réputation.'
                    );
                    return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }
            }

            const tier = reputation.getReputationTier();
            const rank = await ReputationManager.getUserRank(userId);
            const nextLevelExp = (reputation.level * 1000) - reputation.experience;

            // Calculer le pourcentage de progression vers le niveau suivant
            const currentLevelExp = reputation.experience - ((reputation.level - 1) * 1000);
            const expForNextLevel = 1000;
            const progressPercent = Math.round((currentLevelExp / expForNextLevel) * 100);

            // Créer la barre de progression
            const progressBar = this.createProgressBar(progressPercent);

            // Badges obtenus
            const badgeEmojis = {
                trustworthy_trader: '🤝',
                big_spender: '💰',
                entrepreneur: '🏢',
                bank_manager: '🏦',
                market_maker: '📈',
                rookie_trader: '🌱',
                veteran_trader: '🎖️',
                whale: '🐋',
                penny_pincher: '🪙',
                speed_trader: '⚡'
            };

            const badgesText = reputation.badges.length > 0 
                ? reputation.badges.map(badge => `${badgeEmojis[badge] || '🏅'} ${badge.replace('_', ' ')}`).join('\n')
                : 'Aucun badge obtenu';

            // Derniers achievements
            const recentAchievements = reputation.achievements
                .slice(-3)
                .reverse()
                .map(a => `${a.icon} ${a.description}`)
                .join('\n') || 'Aucun achievement récent';

            const reputationEmbed = createInfoEmbed(
                `${tier.emoji} Profil de Réputation - ${targetUser.username}`,
                `**${tier.name}** (${reputation.score}/1000)\n\n` +
                `**📊 Statistiques Générales**\n` +
                `🏆 Rang: #${rank}\n` +
                `⭐ Niveau: ${reputation.level}\n` +
                `✨ Expérience: ${reputation.experience} XP\n` +
                `${progressBar} ${progressPercent}% vers niveau ${reputation.level + 1}\n\n` +
                `**💼 Statistiques de Trading**\n` +
                `✅ Ventes réussies: ${reputation.trading_stats.successful_sales}\n` +
                `🛒 Achats réussis: ${reputation.trading_stats.successful_purchases}\n` +
                `💰 Volume total: ${reputation.trading_stats.total_volume} 💵\n` +
                `❌ Commandes annulées: ${reputation.trading_stats.cancelled_orders}\n`
            );

            reputationEmbed.setColor(tier.color);
            
            if (reputation.badges.length > 0) {
                reputationEmbed.addFields({
                    name: '🏅 Badges Obtenus',
                    value: badgesText,
                    inline: false
                });
            }

            if (reputation.achievements.length > 0) {
                reputationEmbed.addFields({
                    name: '🎯 Achievements Récents',
                    value: recentAchievements,
                    inline: false
                });
            }

            // Conseils pour améliorer la réputation
            if (reputation.score < 700) {
                reputationEmbed.addFields({
                    name: '💡 Conseils pour améliorer votre réputation',
                    value: '• Effectuez des transactions régulières\n• Évitez d\'annuler vos commandes\n• Maintenez un bon stock en tant que vendeur\n• Participez activement au marché',
                    inline: false
                });
            }

            await interaction.reply({ embeds: [reputationEmbed] });

        } catch (error) {
            console.error('Erreur lors de l\'affichage de la réputation:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors de l\'affichage de la réputation.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    },

    createProgressBar(percent) {
        const barLength = 10;
        const filledLength = Math.round((percent / 100) * barLength);
        const emptyLength = barLength - filledLength;
        
        return '▓'.repeat(filledLength) + '░'.repeat(emptyLength);
    }
};