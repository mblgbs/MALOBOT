const { SlashCommandBuilder } = require('discord.js');
const ReputationManager = require('../../utils/reputationManager');
const { createInfoEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('Affiche le classement des meilleurs traders')
        .addStringOption(option =>
            option.setName('type')
                .setDescription('Type de classement')
                .setRequired(false)
                .addChoices(
                    { name: 'Réputation', value: 'reputation' },
                    { name: 'Niveau', value: 'level' },
                    { name: 'Volume de trading', value: 'volume' }
                )
        ),
    
    async execute(interaction) {
        const leaderboardType = interaction.options.getString('type') || 'reputation';

        try {
            const leaderboard = await ReputationManager.getLeaderboard(10);
            const guild = interaction.guild;

            if (!leaderboard || leaderboard.length === 0) {
                const errorEmbed = createErrorEmbed(
                    'Classement vide',
                    'Aucun utilisateur trouvé dans le classement.'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            let title, description;
            let sortedLeaderboard = [...leaderboard];

            switch (leaderboardType) {
                case 'level':
                    sortedLeaderboard.sort((a, b) => b.level - a.level || b.experience - a.experience);
                    title = '🏆 Classement par Niveau';
                    description = 'Les traders avec le plus haut niveau';
                    break;
                case 'volume':
                    sortedLeaderboard.sort((a, b) => b.trading_stats.total_volume - a.trading_stats.total_volume);
                    title = '💰 Classement par Volume';
                    description = 'Les traders avec le plus gros volume de transactions';
                    break;
                default:
                    title = '⭐ Classement par Réputation';
                    description = 'Les traders avec la meilleure réputation';
                    break;
            }

            let leaderboardText = '';
            const medals = ['🥇', '🥈', '🥉'];

            for (let i = 0; i < Math.min(10, sortedLeaderboard.length); i++) {
                const rep = sortedLeaderboard[i];
                const tier = rep.getReputationTier();
                
                try {
                    const member = await guild.members.fetch(rep.user_id);
                    const username = member.displayName;
                    const medal = i < 3 ? medals[i] : `**${i + 1}.**`;
                    
                    let valueText;
                    switch (leaderboardType) {
                        case 'level':
                            valueText = `Niveau ${rep.level} (${rep.experience} XP)`;
                            break;
                        case 'volume':
                            valueText = `${rep.trading_stats.total_volume} 💵 échangés`;
                            break;
                        default:
                            valueText = `${tier.emoji} ${rep.score}/1000`;
                            break;
                    }
                    
                    leaderboardText += `${medal} **${username}** - ${valueText}\n`;
                } catch (error) {
                    // Si l'utilisateur n'est plus sur le serveur, utiliser l'ID
                    const medal = i < 3 ? medals[i] : `**${i + 1}.**`;
                    let valueText;
                    switch (leaderboardType) {
                        case 'level':
                            valueText = `Niveau ${rep.level}`;
                            break;
                        case 'volume':
                            valueText = `${rep.trading_stats.total_volume} 💵`;
                            break;
                        default:
                            valueText = `${rep.score}/1000`;
                            break;
                    }
                    leaderboardText += `${medal} Utilisateur#${rep.user_id.slice(-4)} - ${valueText}\n`;
                }
            }

            const leaderboardEmbed = createInfoEmbed(title, description + '\n\n' + leaderboardText);
            leaderboardEmbed.setColor('#FFD700');

            // Ajouter la position de l'utilisateur actuel
            const userRank = await ReputationManager.getUserRank(interaction.user.id);
            if (userRank && userRank > 10) {
                leaderboardEmbed.addFields({
                    name: '📍 Votre Position',
                    value: `Vous êtes classé #${userRank}`,
                    inline: false
                });
            }

            await interaction.reply({ embeds: [leaderboardEmbed] });

        } catch (error) {
            console.error('Erreur lors de l\'affichage du classement:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors de l\'affichage du classement.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};