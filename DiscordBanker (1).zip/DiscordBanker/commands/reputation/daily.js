const { SlashCommandBuilder } = require('discord.js');
const Reputation = require('../../models/Reputation');
const User = require('../../models/User');
const ReputationManager = require('../../utils/reputationManager');
const { createSuccessEmbed, createErrorEmbed, createInfoEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('daily')
        .setDescription('Réclamez votre récompense quotidienne'),
    
    async execute(interaction) {
        const userId = interaction.user.id;

        try {
            // Initialiser la réputation si nécessaire
            let reputation = await ReputationManager.initializeReputation(userId);
            let user = await User.findOne({ user_id: userId });

            if (!user) {
                const errorEmbed = createErrorEmbed(
                    'Compte inexistant',
                    'Vous devez d\'abord ouvrir un compte avec `/ouvrir_compte`'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Vérifier si l'utilisateur peut récupérer sa récompense quotidienne
            const now = new Date();
            const lastDaily = reputation.last_daily_reward ? new Date(reputation.last_daily_reward) : null;
            
            if (lastDaily) {
                const timeDiff = now - lastDaily;
                const hoursDiff = timeDiff / (1000 * 60 * 60);
                
                if (hoursDiff < 24) {
                    const hoursRemaining = Math.ceil(24 - hoursDiff);
                    const errorEmbed = createErrorEmbed(
                        '⏰ Récompense déjà réclamée',
                        `Vous avez déjà réclamé votre récompense quotidienne.\n\n` +
                        `Revenez dans **${hoursRemaining} heures** pour votre prochaine récompense !`
                    );
                    return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }
            }

            // Calculer les récompenses basées sur le niveau et la réputation
            const tier = reputation.getReputationTier();
            const baseReward = 100;
            const levelBonus = reputation.level * 25;
            const reputationBonus = Math.floor(reputation.score / 100) * 10;
            const totalMoney = baseReward + levelBonus + reputationBonus;
            const experienceReward = 50 + (reputation.level * 5);

            // Bonus de streak (consécutif)
            let streak = reputation.daily_streak || 0;
            if (lastDaily && hoursDiff < 48) {
                streak += 1;
            } else {
                streak = 1;
            }

            const streakBonus = Math.min(streak * 10, 100); // Max 100 bonus
            const finalMoney = totalMoney + streakBonus;

            // Appliquer les récompenses
            user.wallet += finalMoney;
            reputation.experience += experienceReward;
            reputation.last_daily_reward = now;
            reputation.daily_streak = streak;

            // Vérifier level up
            const oldLevel = reputation.level;
            const newLevel = reputation.calculateLevel();
            let leveledUp = false;

            if (newLevel > oldLevel) {
                reputation.level = newLevel;
                reputation.score += (newLevel - oldLevel) * 10;
                leveledUp = true;
            }

            await user.save();
            await reputation.save();

            // Vérifier les achievements
            const newAchievements = await ReputationManager.checkAchievements(userId);

            let rewardText = `**💰 Argent reçu :** ${finalMoney} 💵\n` +
                           `**✨ Expérience :** +${experienceReward} XP\n` +
                           `**🔥 Streak :** ${streak} jours (+${streakBonus} 💵 bonus)\n\n` +
                           `**💼 Nouveau solde :** ${user.wallet} 💵`;

            if (leveledUp) {
                rewardText += `\n\n🎉 **LEVEL UP !** Vous êtes maintenant niveau ${newLevel} !`;
            }

            // Récompenses spéciales pour les streaks
            let specialReward = '';
            if (streak === 7) {
                const bonusXP = 200;
                reputation.experience += bonusXP;
                await reputation.save();
                specialReward = `\n\n🎊 **BONUS HEBDOMADAIRE !** +${bonusXP} XP supplémentaires !`;
            } else if (streak === 30) {
                const bonusMoney = 5000;
                user.wallet += bonusMoney;
                await user.save();
                specialReward = `\n\n🏆 **BONUS MENSUEL !** +${bonusMoney} 💵 supplémentaires !`;
            }

            const dailyEmbed = createSuccessEmbed(
                `${tier.emoji} Récompense Quotidienne Réclamée !`,
                rewardText + specialReward
            );

            dailyEmbed.setColor(tier.color);
            dailyEmbed.addFields(
                { name: '📊 Détails des Récompenses', value: 
                    `Base: ${baseReward} 💵\n` +
                    `Bonus niveau: +${levelBonus} 💵\n` +
                    `Bonus réputation: +${reputationBonus} 💵\n` +
                    `Bonus streak: +${streakBonus} 💵`, inline: true },
                { name: '🎯 Prochaine Récompense', value: 'Dans 24 heures', inline: true }
            );

            await interaction.reply({ embeds: [dailyEmbed] });

            // Notifier les nouveaux achievements
            if (newAchievements.length > 0) {
                for (const achievement of newAchievements) {
                    const achievementEmbed = createSuccessEmbed(
                        `🎉 Nouvel Achievement Débloqué !`,
                        `${achievement.icon} **${achievement.description}**\n\n` +
                        `+${achievement.experience} XP bonus !`
                    );
                    
                    try {
                        await interaction.followUp({ embeds: [achievementEmbed], ephemeral: true });
                    } catch (error) {
                        console.log('Impossible d\'envoyer la notification d\'achievement');
                    }
                }
            }

        } catch (error) {
            console.error('Erreur lors de la récompense quotidienne:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors de la réclamation de votre récompense.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};