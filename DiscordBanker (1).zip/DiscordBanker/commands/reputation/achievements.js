const { SlashCommandBuilder } = require('discord.js');
const Reputation = require('../../models/Reputation');
const { createInfoEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('achievements')
        .setDescription('Affiche vos achievements et progression')
        .addUserOption(option =>
            option.setName('utilisateur')
                .setDescription('Voir les achievements d\'un autre utilisateur')
                .setRequired(false)
        ),
    
    async execute(interaction) {
        const targetUser = interaction.options.getUser('utilisateur') || interaction.user;
        const userId = targetUser.id;

        try {
            const reputation = await Reputation.findOne({ user_id: userId });
            
            if (!reputation) {
                const errorEmbed = createErrorEmbed(
                    'Aucune donnée',
                    'Cet utilisateur n\'a pas encore de profil de réputation.'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Achievements disponibles
            const allAchievements = [
                { name: 'first_sale', description: 'Effectuer votre première vente', icon: '🎉', requirement: '1 vente' },
                { name: 'merchant', description: 'Effectuer 10 ventes avec succès', icon: '🏪', requirement: '10 ventes' },
                { name: 'big_trader', description: 'Atteindre 10,000 💵 de volume', icon: '💰', requirement: '10,000 💵' },
                { name: 'trusted_seller', description: 'Score de réputation 800+', icon: '⭐', requirement: '800+ réputation' },
                { name: 'active_trader', description: 'Effectuer 20 achats avec succès', icon: '🛒', requirement: '20 achats' },
                { name: 'market_veteran', description: 'Atteindre le niveau 10', icon: '🏆', requirement: 'Niveau 10' }
            ];

            const unlockedAchievements = reputation.achievements.map(a => a.name);
            
            let achievementsText = '';
            let lockedText = '';

            for (const achievement of allAchievements) {
                if (unlockedAchievements.includes(achievement.name)) {
                    const earnedAchievement = reputation.achievements.find(a => a.name === achievement.name);
                    const earnedDate = earnedAchievement ? new Date(earnedAchievement.earned_at).toLocaleDateString('fr-FR') : 'Inconnu';
                    achievementsText += `✅ ${achievement.icon} **${achievement.description}**\n📅 Obtenu le ${earnedDate}\n\n`;
                } else {
                    lockedText += `🔒 ${achievement.icon} **${achievement.description}**\n📋 Requis: ${achievement.requirement}\n\n`;
                }
            }

            const achievementsEmbed = createInfoEmbed(
                `🏆 Achievements - ${targetUser.username}`,
                `**${unlockedAchievements.length}/${allAchievements.length} achievements obtenus**\n\n` +
                `**🎯 ACHIEVEMENTS OBTENUS**\n${achievementsText || 'Aucun achievement obtenu pour le moment.\n\n'}` +
                `**🔐 ACHIEVEMENTS VERROUILLÉS**\n${lockedText || 'Tous les achievements sont débloqués !'}`
            );

            achievementsEmbed.setColor('#FFD700');

            // Calculer le prochain achievement le plus proche
            const stats = reputation.trading_stats;
            const nextAchievements = [];

            if (!unlockedAchievements.includes('first_sale') && stats.successful_sales === 0) {
                nextAchievements.push('Effectuez votre première vente');
            }
            if (!unlockedAchievements.includes('merchant') && stats.successful_sales < 10) {
                nextAchievements.push(`${10 - stats.successful_sales} ventes restantes pour "Merchant"`);
            }
            if (!unlockedAchievements.includes('big_trader') && stats.total_volume < 10000) {
                nextAchievements.push(`${10000 - stats.total_volume} 💵 restants pour "Big Trader"`);
            }
            if (!unlockedAchievements.includes('active_trader') && stats.successful_purchases < 20) {
                nextAchievements.push(`${20 - stats.successful_purchases} achats restants pour "Active Trader"`);
            }

            if (nextAchievements.length > 0) {
                achievementsEmbed.addFields({
                    name: '🎯 Prochains Objectifs',
                    value: nextAchievements.slice(0, 3).join('\n'),
                    inline: false
                });
            }

            await interaction.reply({ embeds: [achievementsEmbed] });

        } catch (error) {
            console.error('Erreur lors de l\'affichage des achievements:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors de l\'affichage des achievements.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};