const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const User = require('../../models/User');
const Order = require('../../models/Order');
const { createSuccessEmbed, createErrorEmbed, createInfoEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('acheter')
        .setDescription('Acheter un article sur le marketplace')
        .addStringOption(option =>
            option.setName('article')
                .setDescription('Nom de l\'article à acheter')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('quantite')
                .setDescription('Quantité à acheter')
                .setRequired(true)
                .setMinValue(1)
        ),
    
    async execute(interaction) {
        const buyerId = interaction.user.id;
        const itemName = interaction.options.getString('article').toLowerCase();
        const quantity = interaction.options.getInteger('quantite');

        try {
            // Trouver l'acheteur
            const buyer = await User.findOne({ user_id: buyerId });
            if (!buyer || !buyer.bank) {
                const errorEmbed = createErrorEmbed(
                    'Compte inexistant',
                    'Vous devez d\'abord ouvrir un compte avec `/ouvrir_compte`'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Trouver les vendeurs qui ont cet article
            const sellers = await User.find({
                role: 'vendeur',
                [`stock.${itemName}`]: { $exists: true }
            });

            if (sellers.length === 0) {
                const errorEmbed = createErrorEmbed(
                    'Article non disponible',
                    `Aucun vendeur ne propose **${itemName}** actuellement.`
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Trouver le vendeur avec le stock suffisant et le meilleur prix
            let bestSeller = null;
            let bestPrice = Infinity;

            for (const seller of sellers) {
                const stockData = seller.stock.get(itemName);
                if (stockData && stockData.quantity >= quantity && stockData.price < bestPrice) {
                    bestSeller = seller;
                    bestPrice = stockData.price;
                }
            }

            if (!bestSeller) {
                const errorEmbed = createErrorEmbed(
                    'Stock insuffisant',
                    `Aucun vendeur n'a assez de **${itemName}** en stock (${quantity} demandés).`
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            const totalPrice = bestPrice * quantity;

            // Vérifier que l'acheteur a assez d'argent
            if (buyer.wallet < totalPrice) {
                const errorEmbed = createErrorEmbed(
                    'Fonds insuffisants',
                    `Cette commande coûte **${totalPrice} 💵** mais vous n'avez que **${buyer.wallet} 💵** dans votre portefeuille.\n\n` +
                    `Utilisez \`/retirer\` pour transférer de l'argent de votre banque.`
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Créer la commande
            const order = new Order({
                buyer_id: buyerId,
                seller_id: bestSeller.user_id,
                item: itemName,
                quantity: quantity,
                price_total: totalPrice,
                status: 'pending'
            });

            await order.save();

            // Réserver temporairement l'argent (on le retire du portefeuille)
            buyer.wallet -= totalPrice;
            await buyer.save();

            // Notifier le vendeur
            const guild = interaction.guild;
            const sellerChannel = guild.channels.cache.get(bestSeller.shop_channel_id);
            
            if (sellerChannel) {
                const orderButtons = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`accept_order_${order._id}`)
                            .setLabel('Accepter')
                            .setStyle(ButtonStyle.Success)
                            .setEmoji('✅'),
                        new ButtonBuilder()
                            .setCustomId(`reject_order_${order._id}`)
                            .setLabel('Refuser')
                            .setStyle(ButtonStyle.Danger)
                            .setEmoji('❌')
                    );

                const orderEmbed = createInfoEmbed(
                    '📦 Nouvelle Commande',
                    `**Acheteur :** <@${buyerId}>\n` +
                    `**Article :** ${itemName}\n` +
                    `**Quantité :** ${quantity}\n` +
                    `**Prix unitaire :** ${bestPrice} 💵\n` +
                    `**Prix total :** ${totalPrice} 💵\n\n` +
                    `⏰ En attente de votre réponse...`
                );

                const orderMessage = await sellerChannel.send({
                    embeds: [orderEmbed],
                    components: [orderButtons]
                });

                // Enregistrer l'ID du message pour les boutons
                order.message_id = orderMessage.id;
                await order.save();
            }

            // Confirmer à l'acheteur
            const confirmEmbed = createSuccessEmbed(
                '🛒 Commande envoyée',
                `Votre commande a été envoyée à **${bestSeller.user_id}** :\n\n` +
                `**Article :** ${itemName}\n` +
                `**Quantité :** ${quantity}\n` +
                `**Prix total :** ${totalPrice} 💵\n\n` +
                `💰 L'argent a été réservé de votre portefeuille.\n` +
                `⏳ En attente de confirmation du vendeur...`
            );

            await interaction.reply({ embeds: [confirmEmbed] });

        } catch (error) {
            console.error('Erreur lors de l\'achat:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors de votre achat.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
