const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const ReputationManager = require('../../utils/reputationManager');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('payer')
        .setDescription('Transférer de l\'argent à un autre joueur')
        .addUserOption(option =>
            option.setName('destinataire')
                .setDescription('Le joueur à qui envoyer l\'argent')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('montant')
                .setDescription('Montant à transférer')
                .setRequired(true)
                .setMinValue(1)
        )
        .addStringOption(option =>
            option.setName('source')
                .setDescription('Source des fonds')
                .setRequired(false)
                .addChoices(
                    { name: 'Portefeuille', value: 'wallet' },
                    { name: 'Banque', value: 'bank' }
                )
        ),
    
    async execute(interaction) {
        const userId = interaction.user.id;
        const destinataire = interaction.options.getUser('destinataire');
        const montant = interaction.options.getInteger('montant');
        const source = interaction.options.getString('source') || 'wallet';

        // Vérifier que l'utilisateur ne se paie pas lui-même
        if (destinataire.id === userId) {
            const errorEmbed = createErrorEmbed(
                'Transfert invalide',
                '❌ Vous ne pouvez pas vous transférer de l\'argent à vous-même.'
            );
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        try {
            // Obtenir les données de l'expéditeur et du destinataire
            const expediteur = await User.findOne({ user_id: userId });
            let receveur = await User.findOne({ user_id: destinataire.id });

            if (!expediteur || !expediteur.bank) {
                const errorEmbed = createErrorEmbed(
                    'Compte inexistant',
                    'Vous devez d\'abord ouvrir un compte avec `/ouvrir_compte`'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Créer un compte pour le destinataire s'il n'en a pas
            if (!receveur) {
                receveur = new User({ 
                    user_id: destinataire.id,
                    bank: {
                        solde: 0,
                        actifs: [],
                        dettes: [],
                        historique: [`Compte créé automatiquement - ${new Date().toLocaleString('fr-FR')}`]
                    }
                });
            } else if (!receveur.bank) {
                receveur.bank = {
                    solde: 0,
                    actifs: [],
                    dettes: [],
                    historique: [`Compte bancaire créé automatiquement - ${new Date().toLocaleString('fr-FR')}`]
                };
            }

            // Vérifier les fonds disponibles
            let fondsDisponibles;
            let sourceText;
            
            if (source === 'bank') {
                fondsDisponibles = expediteur.bank.solde;
                sourceText = 'banque';
            } else {
                fondsDisponibles = expediteur.wallet;
                sourceText = 'portefeuille';
            }

            if (fondsDisponibles < montant) {
                const errorEmbed = createErrorEmbed(
                    'Fonds insuffisants',
                    `Vous n'avez que **${fondsDisponibles} 💵** dans votre ${sourceText}.`
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Effectuer le transfert
            if (source === 'bank') {
                expediteur.bank.solde -= montant;
            } else {
                expediteur.wallet -= montant;
            }
            
            receveur.wallet += montant;

            // Ajouter à l'historique
            const dateStr = new Date().toLocaleString('fr-FR');
            expediteur.bank.historique.push(`Paiement envoyé à ${destinataire.username}: ${montant} 💵 - ${dateStr}`);
            receveur.bank.historique.push(`Paiement reçu de ${interaction.user.username}: ${montant} 💵 - ${dateStr}`);

            // Sauvegarder les modifications
            await expediteur.save();
            await receveur.save();

            // Bonus de réputation pour les gros transferts
            if (montant >= 500) {
                await ReputationManager.addExperience(userId, 5, 'Transfert important');
                await ReputationManager.updateReputationScore(userId, 1, 'Activité économique');
            }

            const successEmbed = createSuccessEmbed(
                '💸 Paiement effectué',
                `**${montant} 💵** ont été transférés avec succès à **${destinataire.username}**.\n\n` +
                `💼 Source : ${sourceText}\n` +
                `👛 Votre nouveau solde (${sourceText}) : **${source === 'bank' ? expediteur.bank.solde : expediteur.wallet} 💵**`
            );

            await interaction.reply({ embeds: [successEmbed] });

            // Notification au destinataire (tentative dans un channel visible)
            try {
                const notificationEmbed = createSuccessEmbed(
                    '💰 Paiement reçu',
                    `Vous avez reçu **${montant} 💵** de **${interaction.user.username}**!\n\n` +
                    `💰 Nouveau solde portefeuille : **${receveur.wallet} 💵**`
                );
                
                await destinataire.send({ embeds: [notificationEmbed] });
            } catch (error) {
                console.log('Impossible d\'envoyer une notification privée au destinataire');
            }

        } catch (error) {
            console.error('Erreur lors du paiement:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors du transfert.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};