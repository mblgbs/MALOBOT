const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const ReputationManager = require('../../utils/reputationManager');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('deposer')
        .setDescription('Dépose de l\'argent de votre portefeuille vers la banque')
        .addIntegerOption(option =>
            option.setName('montant')
                .setDescription('Montant à déposer')
                .setRequired(true)
                .setMinValue(1)
        ),
    
    async execute(interaction) {
        const userId = interaction.user.id;
        const montant = interaction.options.getInteger('montant');

        try {
            const user = await User.findOne({ user_id: userId });

            if (!user || !user.bank) {
                const errorEmbed = createErrorEmbed(
                    'Compte inexistant',
                    'Vous devez d\'abord ouvrir un compte avec `/ouvrir_compte`'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            if (user.wallet < montant) {
                const errorEmbed = createErrorEmbed(
                    'Fonds insuffisants',
                    `Vous n'avez que **${user.wallet} 💵** dans votre portefeuille.`
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Effectuer le transfert
            user.wallet -= montant;
            user.bank.solde += montant;
            user.bank.historique.push(`Dépôt de ${montant} 💵 - ${new Date().toLocaleString('fr-FR')}`);

            await user.save();

            // Bonus de réputation pour gestion financière responsable
            if (montant >= 1000) {
                await ReputationManager.addExperience(userId, 10, 'Gros dépôt bancaire');
                await ReputationManager.updateReputationScore(userId, 1, 'Gestion financière');
            }

            const successEmbed = createSuccessEmbed(
                '💰 Dépôt effectué',
                `**${montant} 💵** ont été déposés avec succès.\n\n` +
                `💼 Nouveau solde bancaire : **${user.bank.solde} 💵**\n` +
                `👛 Portefeuille restant : **${user.wallet} 💵**`
            );

            await interaction.reply({ embeds: [successEmbed] });

        } catch (error) {
            console.error('Erreur lors du dépôt:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors du dépôt.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
