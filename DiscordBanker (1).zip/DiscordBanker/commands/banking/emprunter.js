const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const { createSuccessEmbed, createErrorEmbed, createWarningEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('emprunter')
        .setDescription('Emprunter de l\'argent à la banque (avec intérêts)')
        .addIntegerOption(option =>
            option.setName('montant')
                .setDescription('Montant à emprunter')
                .setRequired(true)
                .setMinValue(100)
                .setMaxValue(10000)
        )
        .addIntegerOption(option =>
            option.setName('duree')
                .setDescription('Durée de remboursement en jours')
                .setRequired(false)
                .setMinValue(7)
                .setMaxValue(90)
        ),
    
    async execute(interaction) {
        const userId = interaction.user.id;
        const montant = interaction.options.getInteger('montant');
        const duree = interaction.options.getInteger('duree') || 30; // 30 jours par défaut

        try {
            const user = await User.findOne({ user_id: userId });

            if (!user || !user.bank) {
                const errorEmbed = createErrorEmbed(
                    'Compte inexistant',
                    'Vous devez d\'abord ouvrir un compte avec `/ouvrir_compte`'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Calculer les intérêts (2% par semaine)
            const tauxInteret = 0.02;
            const semaines = Math.ceil(duree / 7);
            const interets = Math.round(montant * tauxInteret * semaines);
            const montantTotal = montant + interets;

            // Vérifier s'il n'y a pas déjà trop de dettes
            const dettesTotales = user.bank.dettes.reduce((total, dette) => {
                const detteParts = dette.split('|');
                if (detteParts.length >= 2) {
                    const montantDette = parseInt(detteParts[1]) || 0;
                    return total + montantDette;
                }
                return total;
            }, 0);

            if (dettesTotales + montantTotal > user.wallet + user.bank.solde + 5000) {
                const errorEmbed = createErrorEmbed(
                    'Emprunt refusé',
                    'Votre capacité d\'endettement est insuffisante.\n' +
                    `Dettes actuelles : **${dettesTotales} 💵**\n` +
                    `Capacité maximale : **${user.wallet + user.bank.solde + 5000} 💵**`
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Créer la dette
            const dateEcheance = new Date();
            dateEcheance.setDate(dateEcheance.getDate() + duree);
            
            const detteId = `PRET_${Date.now()}`;
            const detteString = `${detteId}|${montantTotal}|${dateEcheance.toISOString()}|${montant}|${interets}`;
            
            // Ajouter les fonds et la dette
            user.wallet += montant;
            user.bank.dettes.push(detteString);
            user.bank.historique.push(
                `Emprunt de ${montant} 💵 (${interets} 💵 d'intérêts) - Échéance: ${dateEcheance.toLocaleDateString('fr-FR')} - ${new Date().toLocaleString('fr-FR')}`
            );

            await user.save();

            const warningEmbed = createWarningEmbed(
                '🏦 Emprunt accordé',
                `**Montant emprunté :** ${montant} 💵\n` +
                `**Intérêts (${tauxInteret * 100}% par semaine) :** ${interets} 💵\n` +
                `**Montant total à rembourser :** ${montantTotal} 💵\n` +
                `**Durée :** ${duree} jours\n` +
                `**Date d'échéance :** ${dateEcheance.toLocaleDateString('fr-FR')}\n\n` +
                `💰 L'argent a été ajouté à votre portefeuille.\n` +
                `⚠️ Utilisez \`/rembourser\` pour rembourser vos dettes.`
            );

            warningEmbed.addFields(
                { name: '📋 ID de l\'emprunt', value: detteId, inline: true },
                { name: '💳 Nouveau solde portefeuille', value: `${user.wallet} 💵`, inline: true }
            );

            await interaction.reply({ embeds: [warningEmbed] });

        } catch (error) {
            console.error('Erreur lors de l\'emprunt:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors de la demande d\'emprunt.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};