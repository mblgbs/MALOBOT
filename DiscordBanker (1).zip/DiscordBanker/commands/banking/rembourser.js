const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const ReputationManager = require('../../utils/reputationManager');
const { createSuccessEmbed, createErrorEmbed, createInfoEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rembourser')
        .setDescription('Rembourser une dette ou voir vos dettes')
        .addStringOption(option =>
            option.setName('action')
                .setDescription('Action à effectuer')
                .setRequired(false)
                .addChoices(
                    { name: 'Voir mes dettes', value: 'voir' },
                    { name: 'Rembourser une dette', value: 'payer' }
                )
        )
        .addStringOption(option =>
            option.setName('id_dette')
                .setDescription('ID de la dette à rembourser')
                .setRequired(false)
        )
        .addIntegerOption(option =>
            option.setName('montant')
                .setDescription('Montant à rembourser (partiel ou total)')
                .setRequired(false)
                .setMinValue(1)
        ),
    
    async execute(interaction) {
        const userId = interaction.user.id;
        const action = interaction.options.getString('action') || 'voir';
        const idDette = interaction.options.getString('id_dette');
        const montantRemboursement = interaction.options.getInteger('montant');

        try {
            const user = await User.findOne({ user_id: userId });

            if (!user || !user.bank) {
                const errorEmbed = createErrorEmbed(
                    'Compte inexistant',
                    'Vous devez d\'abord ouvrir un compte avec `/ouvrir_compte`'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            if (!user.bank.dettes || user.bank.dettes.length === 0) {
                const infoEmbed = createInfoEmbed(
                    '✅ Aucune dette',
                    'Félicitations ! Vous n\'avez aucune dette en cours.'
                );
                return interaction.reply({ embeds: [infoEmbed] });
            }

            if (action === 'voir') {
                // Afficher toutes les dettes
                let dettesText = '';
                let totalDettes = 0;

                user.bank.dettes.forEach((dette, index) => {
                    const detteParts = dette.split('|');
                    if (detteParts.length >= 5) {
                        const [id, montantTotal, dateEcheance, montantInitial, interets] = detteParts;
                        const date = new Date(dateEcheance);
                        const isEnRetard = date < new Date();
                        
                        dettesText += `**${index + 1}.** ${id}\n`;
                        dettesText += `   💰 Montant restant : **${montantTotal} 💵**\n`;
                        dettesText += `   📅 Échéance : ${date.toLocaleDateString('fr-FR')} ${isEnRetard ? '🔴 **EN RETARD**' : '🟢'}\n`;
                        dettesText += `   📊 Initial : ${montantInitial} 💵 | Intérêts : ${interets} 💵\n\n`;
                        
                        totalDettes += parseInt(montantTotal);
                    }
                });

                const dettesEmbed = createInfoEmbed(
                    '📋 Vos dettes en cours',
                    dettesText || 'Aucune dette'
                );

                dettesEmbed.addFields(
                    { name: '💳 Total des dettes', value: `${totalDettes} 💵`, inline: true },
                    { name: '💰 Fonds disponibles', value: `${user.wallet + user.bank.solde} 💵`, inline: true },
                    { name: '📝 Comment rembourser', value: 'Utilisez `/rembourser action:payer id_dette:PRET_XXX montant:XXX`', inline: false }
                );

                await interaction.reply({ embeds: [dettesEmbed] });
                return;
            }

            if (action === 'payer') {
                if (!idDette) {
                    const errorEmbed = createErrorEmbed(
                        'ID manquant',
                        'Vous devez spécifier l\'ID de la dette à rembourser.\nUtilisez `/rembourser action:voir` pour voir vos dettes.'
                    );
                    return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }

                // Trouver la dette
                const detteIndex = user.bank.dettes.findIndex(dette => dette.startsWith(idDette));
                
                if (detteIndex === -1) {
                    const errorEmbed = createErrorEmbed(
                        'Dette introuvable',
                        'Cette dette n\'existe pas ou a déjà été remboursée.'
                    );
                    return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }

                const detteParts = user.bank.dettes[detteIndex].split('|');
                const [id, montantRestant, dateEcheance, montantInitial, interets] = detteParts;
                const montantDette = parseInt(montantRestant);
                
                // Déterminer le montant à rembourser
                const montantARembourser = montantRemboursement || montantDette;
                
                if (montantARembourser > montantDette) {
                    const errorEmbed = createErrorEmbed(
                        'Montant trop élevé',
                        `Cette dette ne fait que **${montantDette} 💵**. Vous ne pouvez pas rembourser plus.`
                    );
                    return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }

                // Vérifier les fonds disponibles
                const fondsDisponibles = user.wallet + user.bank.solde;
                if (fondsDisponibles < montantARembourser) {
                    const errorEmbed = createErrorEmbed(
                        'Fonds insuffisants',
                        `Vous n'avez que **${fondsDisponibles} 💵** disponibles.\nMontant requis : **${montantARembourser} 💵**`
                    );
                    return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }

                // Effectuer le remboursement
                let resteARetirer = montantARembourser;
                
                // Retirer d'abord du portefeuille, puis de la banque
                if (user.wallet >= resteARetirer) {
                    user.wallet -= resteARetirer;
                } else {
                    resteARetirer -= user.wallet;
                    user.wallet = 0;
                    user.bank.solde -= resteARetirer;
                }

                // Mettre à jour la dette
                const nouveauMontantDette = montantDette - montantARembourser;
                
                if (nouveauMontantDette === 0) {
                    // Dette complètement remboursée
                    user.bank.dettes.splice(detteIndex, 1);
                    user.bank.historique.push(`Dette ${id} remboursée intégralement (${montantARembourser} 💵) - ${new Date().toLocaleString('fr-FR')}`);
                    
                    // Bonus de réputation pour remboursement complet
                    await ReputationManager.addExperience(userId, 15, 'Remboursement complet de dette');
                    await ReputationManager.updateReputationScore(userId, 3, 'Responsabilité financière');
                } else {
                    // Remboursement partiel
                    user.bank.dettes[detteIndex] = `${id}|${nouveauMontantDette}|${dateEcheance}|${montantInitial}|${interets}`;
                    user.bank.historique.push(`Remboursement partiel dette ${id}: ${montantARembourser} 💵 (reste: ${nouveauMontantDette} 💵) - ${new Date().toLocaleString('fr-FR')}`);
                    
                    // Bonus de réputation pour remboursement partiel
                    await ReputationManager.addExperience(userId, 5, 'Remboursement partiel de dette');
                    await ReputationManager.updateReputationScore(userId, 1, 'Gestion des dettes');
                }

                await user.save();

                const successEmbed = createSuccessEmbed(
                    nouveauMontantDette === 0 ? '✅ Dette remboursée' : '💰 Remboursement partiel',
                    nouveauMontantDette === 0 
                        ? `La dette **${id}** a été complètement remboursée !\n\n**Montant remboursé :** ${montantARembourser} 💵`
                        : `**Montant remboursé :** ${montantARembourser} 💵\n**Montant restant :** ${nouveauMontantDette} 💵\n\n**Dette :** ${id}`
                );

                successEmbed.addFields(
                    { name: '💰 Nouveau solde portefeuille', value: `${user.wallet} 💵`, inline: true },
                    { name: '🏦 Nouveau solde banque', value: `${user.bank.solde} 💵`, inline: true }
                );

                await interaction.reply({ embeds: [successEmbed] });
            }

        } catch (error) {
            console.error('Erreur lors du remboursement:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors du remboursement.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};