const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('retirer')
        .setDescription('Retire de l\'argent de la banque vers votre portefeuille')
        .addIntegerOption(option =>
            option.setName('montant')
                .setDescription('Montant à retirer')
                .setRequired(true)
                .setMinValue(1)
        ),
    
    async execute(interaction) {
        const userId = interaction.user.id;
        const montant = interaction.options.getInteger('montant');

        try {
            const user = await User.findOne({ user_id: userId });

            if (!user || !user.bank) {
                const errorEmbed = createErrorEmbed(
                    'Compte inexistant',
                    'Vous devez d\'abord ouvrir un compte avec `/ouvrir_compte`'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            if (user.bank.solde < montant) {
                const errorEmbed = createErrorEmbed(
                    'Fonds insuffisants',
                    `Vous n'avez que **${user.bank.solde} 💵** dans votre compte bancaire.`
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Effectuer le retrait
            user.bank.solde -= montant;
            user.wallet += montant;
            user.bank.historique.push(`Retrait de ${montant} 💵 - ${new Date().toLocaleString('fr-FR')}`);

            await user.save();

            const successEmbed = createSuccessEmbed(
                '🏧 Retrait effectué',
                `**${montant} 💵** ont été retirés avec succès.\n\n` +
                `💼 Nouveau solde bancaire : **${user.bank.solde} 💵**\n` +
                `👛 Nouveau portefeuille : **${user.wallet} 💵**`
            );

            await interaction.reply({ embeds: [successEmbed] });

        } catch (error) {
            console.error('Erreur lors du retrait:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors du retrait.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
