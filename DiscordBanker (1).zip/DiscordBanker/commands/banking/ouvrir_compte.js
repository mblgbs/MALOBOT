const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ouvrir_compte')
        .setDescription('Ouvre un compte bancaire fictif'),
    
    async execute(interaction) {
        const userId = interaction.user.id;

        try {
            // Vérifier si l'utilisateur a déjà un compte
            let user = await User.findOne({ user_id: userId });

            if (user && user.bank && user.bank.solde !== undefined) {
                const errorEmbed = createErrorEmbed(
                    'Compte déjà existant',
                    '❌ Vous avez déjà un compte bancaire ouvert.'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Créer un nouveau compte ou mettre à jour
            if (!user) {
                user = new User({ user_id: userId });
            }

            user.bank = {
                solde: 0,
                actifs: [],
                dettes: [],
                historique: [`Ouverture de compte - ${new Date().toLocaleString('fr-FR')}`]
            };

            await user.save();

            const successEmbed = createSuccessEmbed(
                '🏦 Compte bancaire ouvert',
                `Bienvenue dans **la Banque Malo** !\n\n` +
                `💼 Solde bancaire : **0 💵**\n` +
                `💰 Portefeuille : **${user.wallet} 💵**\n\n` +
                `**Commandes disponibles :**\n` +
                `• \`/deposer\` - Déposer de l'argent à la banque\n` +
                `• \`/retirer\` - Retirer de l'argent de la banque\n` +
                `• \`/balance\` - Voir votre solde total\n` +
                `• \`/bilan\` - Bilan financier complet`
            );

            await interaction.reply({ embeds: [successEmbed] });

        } catch (error) {
            console.error('Erreur lors de la création du compte:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors de la création de votre compte.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
