const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const { createInfoEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('balance')
        .setDescription('Affiche votre solde total (portefeuille + banque)'),
    
    async execute(interaction) {
        const userId = interaction.user.id;

        try {
            const user = await User.findOne({ user_id: userId });

            if (!user) {
                const errorEmbed = createErrorEmbed(
                    'Compte inexistant',
                    'Vous devez d\'abord ouvrir un compte avec `/ouvrir_compte`'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            const bankBalance = user.bank ? user.bank.solde : 0;
            const totalBalance = user.wallet + bankBalance;

            const balanceEmbed = createInfoEmbed(
                '💰 Votre Balance',
                `**Portefeuille :** ${user.wallet} 💵\n` +
                `**Banque :** ${bankBalance} 💵\n` +
                `**━━━━━━━━━━━━━━━━━━**\n` +
                `**Total :** ${totalBalance} 💵`
            );

            balanceEmbed.addFields(
                { name: '📊 Répartition', value: `${Math.round((user.wallet / totalBalance) * 100)}% Portefeuille | ${Math.round((bankBalance / totalBalance) * 100)}% Banque`, inline: false }
            );

            await interaction.reply({ embeds: [balanceEmbed] });

        } catch (error) {
            console.error('Erreur lors de la consultation de balance:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors de la consultation de votre balance.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
