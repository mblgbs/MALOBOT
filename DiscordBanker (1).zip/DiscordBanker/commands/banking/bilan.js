const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const { createInfoEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bilan')
        .setDescription('Affiche votre bilan financier complet'),
    
    async execute(interaction) {
        const userId = interaction.user.id;

        try {
            const user = await User.findOne({ user_id: userId });

            if (!user || !user.bank) {
                const errorEmbed = createErrorEmbed(
                    'Compte inexistant',
                    'Vous devez d\'abord ouvrir un compte avec `/ouvrir_compte`'
                );
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            const totalBalance = user.wallet + user.bank.solde;
            const stockCount = user.stock ? user.stock.size : 0;

            const bilanEmbed = createInfoEmbed(
                '📊 Bilan Financier Complet',
                `**💰 FINANCES**\n` +
                `Portefeuille : ${user.wallet} 💵\n` +
                `Banque : ${user.bank.solde} 💵\n` +
                `**Total : ${totalBalance} 💵**\n\n` +
                `**🏪 COMMERCE**\n` +
                `Statut : ${user.role === 'vendeur' ? '✅ Vendeur' : '❌ Client'}\n` +
                `Articles en stock : ${stockCount}\n\n` +
                `**📈 ACTIFS & DETTES**\n` +
                `Actifs : ${user.bank.actifs.length}\n` +
                `Dettes : ${user.bank.dettes.length}`
            );

            // Ajouter l'historique récent
            if (user.bank.historique.length > 0) {
                const recentHistory = user.bank.historique.slice(-5).reverse();
                bilanEmbed.addFields({
                    name: '📋 Historique Récent',
                    value: recentHistory.join('\n') || 'Aucune transaction',
                    inline: false
                });
            }

            // Ajouter les articles en stock si vendeur
            if (user.role === 'vendeur' && user.stock && user.stock.size > 0) {
                let stockList = '';
                for (const [item, data] of user.stock) {
                    stockList += `**${item}** : ${data.quantity} unités à ${data.price} 💵/u\n`;
                }
                bilanEmbed.addFields({
                    name: '🛒 Stock Actuel',
                    value: stockList || 'Aucun article',
                    inline: false
                });
            }

            await interaction.reply({ embeds: [bilanEmbed] });

        } catch (error) {
            console.error('Erreur lors du bilan:', error);
            const errorEmbed = createErrorEmbed(
                'Erreur système',
                'Une erreur est survenue lors de la génération de votre bilan.'
            );
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
